# 25 Millennium Problem Proposals

**Project:** DEEP_LEARNING_FOR_BCI
**Upstream:** https://github.com/xiangzhang1015/Deep-Learning-for-BCI

Content specific to DEEP_LEARNING_FOR_BCI in category BRAIN_COMPUTER_INTERFACE.
