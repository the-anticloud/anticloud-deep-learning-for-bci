# OSINT Benchmark — DEEP_LEARNING_FOR_BCI

**Upstream:** https://github.com/xiangzhang1015/Deep-Learning-for-BCI

Public-record information collected about upstream project:

- GitHub stars: see upstream
- License: MIT
- Last commit: check upstream
- Known CVEs: check NVD

Status: PENDING systematic collection.
